// Replace placeholders with your Blynk and Wi-Fi details
#define BLYNK_TEMPLATE_ID "TMPL6z_wx7xEb"
#define BLYNK_TEMPLATE_NAME "Wokwi"
#define BLYNK_AUTH_TOKEN "buBXhfqsCJw_s1ev42h4OoXSiKYBBNRN"

#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>

char ssid[] = "Wokwi-GUEST";
char pass[] = "";

#define LED1 16
#define LED2 17
#define LED3 19
#define LED4 21

void setup() {
  pinMode(LED1, OUTPUT);
  pinMode(LED2, OUTPUT);
  pinMode(LED3, OUTPUT);
  pinMode(LED4, OUTPUT);
  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);
}

void loop() {
  Blynk.run();
}

BLYNK_WRITE(V0) { // Controls LED via Blynk Button
  digitalWrite(LED1, param.asInt());
}
BLYNK_WRITE(V1) { // Controls LED via Blynk Button
  digitalWrite(LED2, param.asInt());
}
BLYNK_WRITE(V2) { // Controls LED via Blynk Button
  digitalWrite(LED3, param.asInt());
}
BLYNK_WRITE(V3) { // Controls LED via Blynk Button
  digitalWrite(LED4, param.asInt());
}

